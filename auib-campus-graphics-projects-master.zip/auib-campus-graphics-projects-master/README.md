# auib-campus-graphics-projects
It is a aiub campus senario graphics project
